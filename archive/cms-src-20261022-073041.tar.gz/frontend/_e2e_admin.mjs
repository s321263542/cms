/**
 * S4 后半·第 6 步 验收：Nuxt 假后台切真接口的「浏览器侧等价」链路测试。
 * 走的完全是前端代码同一条路：Nuxt(3111) → nitro routeRules 反代 → 若依 8080。
 *   1. POST /login 拿 JWT（登录页 adminLogin 走这里）
 *   2. 不带 token 打 bootstrap → 应得 401 信封（useAdminApi 的 expired() 认这个）
 *   3. 带 token 打 bootstrap → 8 个模块 + 版本 + 日志（hydrate 吃这份）
 *   4. save_draft 用「与生效版一模一样的快照」→ 后端应判定无改动、不写草稿，
 *      只落一条审计（测完删掉，库保持原样）
 */
const BASE = process.env.BASE || 'http://127.0.0.1:3111'
let pass = 0
let fail = 0
const out = []
function ck(name, cond, extra = '') {
  if (cond) { pass++; out.push(`PASS  ${name}${extra ? '  | ' + extra : ''}`) }
  else { fail++; out.push(`FAIL  ${name}${extra ? '  | ' + extra : ''}`) }
}

async function call(url, opt = {}) {
  const r = await fetch(BASE + url, opt)
  const t = await r.text()
  let body = null
  try { body = JSON.parse(t) } catch { /* html */ }
  return { status: r.status, text: t, body }
}

/* 1. 登录（login.vue → adminLogin → POST /login） */
const lg = await call('/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
  body: JSON.stringify({ username: 'admin', password: 'admin123', code: '', uuid: '' })
})
const token = lg.body?.token || lg.body?.data?.token || ''
ck('POST /login 200 且 code=200', lg.status === 200 && lg.body?.code === 200, `status=${lg.status} code=${lg.body?.code}`)
ck('拿到顶层 token', typeof token === 'string' && token.length > 10, `len=${token.length}`)

/* 1b. 密码错 → 业务失败（adminLogin 读 msg 展示） */
const bad = await call('/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ username: 'admin', password: 'wrong-pass', code: '', uuid: '' })
})
ck('密码错返回可展示的 msg', bad.status === 200 && bad.body?.code !== 200 && !!bad.body?.msg, `code=${bad.body?.code} msg=${bad.body?.msg}`)

/* 2. 无 token → 401 信封（HTTP 可能是 200，看 body.code） */
const anon = await call('/api/admin/cms/bootstrap?lang=zh')
ck('未登录打 bootstrap 被 401 拦下', anon.status === 401 || anon.body?.code === 401, `status=${anon.status} code=${anon.body?.code}`)

/* 3. 带 token → 8 模块 */
const H = { Authorization: `Bearer ${token}`, Accept: 'application/json' }
const bs = await call('/api/admin/cms/bootstrap?lang=zh', { headers: H })
const mods = bs.body?.data?.modules || []
ck('bootstrap 200 且 8 个模块', bs.status === 200 && bs.body?.code === 200 && mods.length === 8, `n=${mods.length} code=${bs.body?.code}`)
const mBanner = mods.find(m => m.key === 'banner')
ck('模块视图带 live/draft 快照', !!mBanner && !!mBanner.live && !!mBanner.draft, JSON.stringify(mBanner ? Object.keys(mBanner) : null))
ck('模块视图带状态字段', !!mBanner && typeof mBanner.online === 'boolean' && typeof mBanner.status === 'string', `status=${mBanner?.status} online=${mBanner?.online}`)
ck('版本与日志是数组', Array.isArray(bs.body?.data?.versions) && Array.isArray(bs.body?.data?.audit),
  `v=${bs.body?.data?.versions?.length} a=${bs.body?.data?.audit?.length}`)

/* 3b. 其余只读端点 */
const vt = await call('/api/admin/cms/versions?lang=zh', { headers: H })
ck('GET /versions 200', vt.status === 200 && vt.body?.code === 200, `code=${vt.body?.code}`)
const au = await call('/api/admin/cms/audit?limit=5', { headers: H })
ck('GET /audit 200', au.status === 200 && au.body?.code === 200, `code=${au.body?.code}`)

/* 4. save_draft：拿生效快照原样回传 = 没有任何改动 */
const auditBefore = au.body?.data?.length ?? -1
const sd = await call('/api/admin/cms/banner/action', {
  method: 'POST',
  headers: { ...H, 'Content-Type': 'application/json' },
  body: JSON.stringify({ action: 'save_draft', lang: 'zh', snapshot: mBanner.live, changes: [] })
})
ck('save_draft 200', sd.status === 200 && sd.body?.code === 200, `code=${sd.body?.code} msg=${sd.body?.msg}`)
ck('返回新模块状态可回填', !!sd.body?.data?.state && sd.body?.data?.state?.key === 'banner',
  `key=${sd.body?.data?.state?.key}`)

/* 5. 只在 /api/admin/cms/** 上反代，CRM 线索接口仍归 Nuxt 自己 */
const lead = await call('/api/admin/lead/list?status=all&pageSize=5', { headers: H })
ck('/api/admin/lead/list 仍由本项目 mock 服务（未被转走）', lead.status === 200 && lead.body?.code === 200,
  `status=${lead.status} code=${lead.body?.code}`)

/* 6. 草稿预览回环（第 7 步：Redis 凭证 + 公网读缓存）——
 *    公网读直连 Java：真后端模式下浏览器就是拿绝对 apiBase 直连的（3111 不反代 /api/public） */
const JAVA = process.env.JAVA || 'http://127.0.0.1:8080'
async function jget(url) {
  const r = await fetch(JAVA + url)
  const t = await r.text()
  let body = null
  try { body = JSON.parse(t) } catch { /* html */ }
  return { status: r.status, text: t, body }
}

const live1 = await jget('/api/public/bank?lang=zh')
const liveName = live1.body?.data?.[0]?.name || ''
ck('Java /bank 生效内容基线', live1.status === 200 && live1.body?.code === 200 && !!liveName, `name=${liveName}`)

const live2 = await jget('/api/public/bank?lang=zh')
ck('二次请求命中缓存且与首次逐字一致', JSON.stringify(live2.body) === JSON.stringify(live1.body),
  `len=${live2.text.length}`)

const pToken = `v1.${Date.now().toString(36)}.${Math.random().toString(36).slice(2, 10)}`
const draftBanks = JSON.parse(JSON.stringify(live1.body.data))
draftBanks[0].name = 'DRAFT-ONLY-BANK'
const pvPush = await call('/api/admin/cms/preview', {
  method: 'POST',
  headers: { ...H, 'Content-Type': 'application/json' },
  body: JSON.stringify({
    token: pToken,
    exp: Date.now() + 30 * 60 * 1000,
    lang: 'zh',
    data: { cfg: {}, sectionOn: {}, banners: [], services: [], banks: draftBanks, cases: [], articles: [] }
  })
})
ck('POST /cms/preview 200', pvPush.status === 200 && pvPush.body?.code === 200,
  `code=${pvPush.body?.code} msg=${pvPush.body?.msg}`)

const pvGet = await jget(`/api/public/bank?lang=zh&preview=${pToken}`)
ck('带 preview 看到草稿', pvGet.body?.data?.[0]?.name === 'DRAFT-ONLY-BANK',
  `name=${pvGet.body?.data?.[0]?.name}`)

const live3 = await jget('/api/public/bank?lang=zh')
ck('不带 preview 仍是生效内容（缓存没被草稿污染）', live3.body?.data?.[0]?.name === liveName,
  `name=${live3.body?.data?.[0]?.name}`)

const pvInfo = await jget(`/api/public/draft-preview?token=${pToken}`)
ck('draft-preview 凭证有效', pvInfo.body?.data?.valid === true, `ttl=${pvInfo.body?.data?.ttlMinutes}`)

const pvEn = await jget(`/api/public/bank?lang=en&preview=${pToken}`)
const enName = pvEn.body?.data?.[0]?.name || ''
ck('en 页面 + zh 草稿 → 语言失配退回生效内容', enName !== 'DRAFT-ONLY-BANK' && !!enName,
  `name=${enName}`)

console.log(out.join('\n'))
console.log(`\n== PASS ${pass} / FAIL ${fail} ==`)
console.log(`AUDIT_BEFORE=${auditBefore}`)
process.exit(fail ? 1 : 0)
