const BASE = 'http://127.0.0.1:3111'
const lg = await fetch(BASE + '/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: 'admin', password: 'admin123', code: '', uuid: '' }) }).then(r => r.json())
const token = lg.token
const H = { Authorization: `Bearer ${token}` }

async function probe(name, url, opts) {
  const r = await fetch(url, opts)
  const t = await r.text()
  console.log(`${name} -> ${r.status} ${t.slice(0, 220)}`)
}

// 直连 Java（不经 Nuxt 代理）
await probe('DIRECT  /api/admin/cms/bootstrap', 'http://127.0.0.1:8080/api/admin/cms/bootstrap?lang=zh', { headers: H })
// 经 Nuxt 代理
await probe('PROXY   /api/admin/cms/bootstrap', `${BASE}/api/admin/cms/bootstrap?lang=zh`, { headers: H })
// 经代理打一个肯定存在的只读端点（对照）
await probe('PROXY   /api/public/config', `${BASE}/api/public/config?lang=zh`)
// 直连 versions（GET 全路径）
await probe('DIRECT  /api/admin/cms/versions', 'http://127.0.0.1:8080/api/admin/cms/versions?lang=zh', { headers: H })
