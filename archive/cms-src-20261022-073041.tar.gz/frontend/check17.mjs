/* round17 附加检查：后台页面无「演示」痕迹 + 关键文案在位 */
const BASE = process.env.BASE || 'http://127.0.0.1:3111'
const cookie = { Cookie: 'yh_admin_token=yh-admin-2026' }

let pass = 0
let fail = 0
const out = []
function ck(name, cond, extra = '') {
  if (cond) {
    pass++
    out.push(`PASS  ${name}${extra ? '  | ' + extra : ''}`)
  } else {
    fail++
    out.push(`FAIL  ${name}${extra ? '  | ' + extra : ''}`)
  }
}

const pages = [
  ['登录页', '/admin/login'], // 登录页必须匿名访问（带有效 cookie 会被服务端导去大屏）
  ['BI 大屏', '/admin'],
  ['CRM', '/admin/crm'],
  ['工作台', '/admin/cms'],
  ['内容审核', '/admin/review'],
  ['操作日志', '/admin/audit']
]
const html = {}
for (const [name, url] of pages) {
  const r = await fetch(BASE + url, name === '登录页' ? {} : { headers: cookie })
  const t = await r.text()
  html[name] = { status: r.status, text: t }
  ck(`${name} 200`, r.status === 200, `status=${r.status}`)
  ck(`${name} 无「演示」`, !t.includes('演示'))
  ck(`${name} 无 flask 图标`, !t.includes('fa-flask'))
  ck(`${name} 无「不写库 / 不影响前台」`, !t.includes('不写库') && !t.includes('不影响前台'))
}

/* 登录页：无演示提示、副标题中性、表单在位 */
const login = html['登录页'].text
ck('登录页副标题改为中性文案', login.includes('使用管理员账号登录内容管理系统'))
ck('登录页无「演示账号」', !login.includes('演示账号'))
ck('登录页账号密码输入框在位', login.includes('id="adm-user"') && login.includes('type="password"'))

/* CRM：计数口径 + 常驻线索 + 归档脚注 */
const crm = html['CRM'].text
ck('CRM 页签计数 128', crm.includes('128'))
ck('CRM 归档脚注 113 条历史线索', crm.includes('113 条历史线索已归档'))
ck('CRM 明细区有内容（待跟进线索）', crm.includes('深圳跨境电商'))
ck('CRM 明细区有内容（跟进中线索）', crm.includes('杭州外贸'))
ck('CRM 明细区有内容（已签约线索）', crm.includes('东莞电子'))
ck('CRM 无内置线索徽章', !crm.includes('内置演示线索'))
ck('CRM 无「实时」徽章', !crm.includes('title="来自前台真实提交"'))

/* 侧边栏：工作台组下挂了「内容审核」「操作日志」两个子菜单 */
const bi = html['BI 大屏'].text
ck('侧边栏有「内容审核」子菜单', bi.includes('内容审核'))
ck('侧边栏有「操作日志」子菜单', bi.includes('操作日志'))

/* 内容审核页：队列表 + 对比预览入口 + 审核动作 */
const review = html['内容审核'].text
ck('审核页标题与说明', review.includes('内容审核') && review.includes('修改前后对比'))
ck('审核页列出 8 个送审单元', review.includes('共 8 个模块'))
ck('审核页每行有「对比预览」', review.includes('对比预览'))
ck('审核页有筛选页签（全部/待审核/有新改动/已发布）', ['全部', '待审核', '有新改动', '已发布'].every(s => review.includes(s)))
ck('审核页说明只列改动字段', review.includes('只显示有改动的字段'))
ck('审核页可跳操作日志与工作台', review.includes('/admin/audit') && review.includes('/admin/cms'))

/* 操作日志页：字段级留痕 + 筛选 + 重置数据 */
const audit = html['操作日志'].text
ck('日志页标题与说明', audit.includes('操作日志') && audit.includes('改前'))
ck('日志页动作分组页签', ['发布', '草稿', '审核', '回滚'].every(s => audit.includes(s)))
ck('日志页有模块与关键词筛选', audit.includes('全部模块') && audit.includes('搜字段名'))
ck('日志页有「全部展开」与「重置数据」', audit.includes('全部展开') && audit.includes('重置数据'))

/* 两个新页面未登录要被挡在门外（redirect:'manual' 才能看到 302，否则会跟到登录页拿到 200） */
for (const url of ['/admin/review', '/admin/audit']) {
  const r = await fetch(BASE + url, { redirect: 'manual' })
  const loc = r.headers.get('location') || ''
  ck(`${url} 未登录 302 到登录页`, r.status === 302 && loc.includes('/admin/login'), `status=${r.status} loc=${loc}`)
}

/* 侧边栏徽标 128 / 23 / 57 / 48 */
for (const n of ['128', '23', '57', '48']) {
  ck(`侧边栏/大屏出现 ${n}`, html['BI 大屏'].text.includes(n))
}

/* 工作台：三按钮 + 重置数据 + 面包屑（不再是演示模式占位） */
const cms = html['工作台'].text
ck('顶栏面包屑「全能管控工作台」', cms.includes('全能管控工作台'))
ck('顶栏无「演示模式」占位', !cms.includes('演示模式'))
ck('工具条按钮 版本记录/操作日志/重置数据', cms.includes('版本记录') && cms.includes('操作日志') && cms.includes('重置数据'))
ck('工具条中性提示条', cms.includes('8 个内容模块'))

/* 抽屉文案由 SSR 拿不到（点击才开），这里只校验前端源码由构建期保证 */

console.log(out.join('\n'))
console.log(`\n== PASS ${pass} / FAIL ${fail} ==`)
process.exit(fail ? 1 : 0)
