#!/bin/bash
# round18 deploy: extract + restart + quick status
set -e
tar -xzf /tmp/round18.tgz -C /home/lx/cms-frontend
pm2 restart cms-frontend > /dev/null 2>&1
sleep 8
echo "EXTRACT_OK"
echo -n "review(anon)="; curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/admin/review
echo ""
echo -n "audit(anon)="; curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/admin/audit
echo ""
echo -n "home="; curl -s -o /dev/null -w "%{http_code}" http://127.0.0.1:3000/zh
echo ""
