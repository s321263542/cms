set -e
cd /home/lx/cms-frontend
tar -xzf /tmp/round19.tgz -C /home/lx/cms-frontend
pm2 restart cms-frontend >/dev/null 2>&1 || true
sleep 4
echo "RESTARTED"
md5sum app/pages/admin/review.vue app/pages/admin/audit.vue app/components/admin/FlowBar.vue app/components/admin/DiffDialog.vue
curl -s -o /dev/null -w "review=%{http_code}\n" http://127.0.0.1:3000/admin/review
curl -s -o /dev/null -w "audit=%{http_code}\n" http://127.0.0.1:3000/admin/audit
curl -s -o /dev/null -w "zh=%{http_code}\n" http://127.0.0.1:3000/zh
