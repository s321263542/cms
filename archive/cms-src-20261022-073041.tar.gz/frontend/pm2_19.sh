pm2 jlist > /tmp/j19.json
node -e "const a=JSON.parse(require('fs').readFileSync('/tmp/j19.json','utf8')); a.forEach(p=>console.log(p.name, p.pm2_env.restart_time))"
