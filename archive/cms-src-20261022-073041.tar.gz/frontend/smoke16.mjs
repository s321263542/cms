/**
 * round16 本地冒烟 —— 草稿 / preview token / 发布链路
 * 跑法：先 `node .output/server/index.mjs`（PORT=3111），再 `node smoke16.mjs`
 */
const BASE = process.env.BASE || 'http://127.0.0.1:3111'
let pass = 0
let fail = 0
const lines = []

function ck(name, cond, extra = '') {
  if (cond) {
    pass++
    lines.push(`PASS  ${name}${extra ? '  | ' + extra : ''}`)
  } else {
    fail++
    lines.push(`FAIL  ${name}${extra ? '  | ' + extra : ''}`)
  }
}

const exp = Date.now() + 30 * 60 * 1000
const TOKEN = `v1.${exp.toString(36)}.smoke16ab`
const BAD_TOKEN = `v1.${(Date.now() + 3600 * 1000 * 24).toString(36)}.smoke16ab` // 篡改过期时间

async function j(url, opt) {
  const r = await fetch(BASE + url, opt)
  const t = await r.text()
  let body = null
  try {
    body = JSON.parse(t)
  } catch {
    /* html */
  }
  return { status: r.status, text: t, body }
}

/* ---------------------------------------------------------------- 1. 推草稿 */
const snap = {
  cfg: {
    site_name: '永鸿国际',
    brand_en: 'YONGHONG INTERNATIONAL CONSULTING',
    company_full: '',
    company_addr: '',
    company_phone: '',
    company_email: '',
    company_credit: '',
    company_regdate: '',
    icp_number: '',
    privacy_version: 'v1.0',
    seo_site_title: '',
    seo_site_desc: '',
    seo_site_kw: '',
    cdn_base: '',
    home_rec: { title: '今日推荐-草稿', num: '', sub: '' },
    home_stats: [],
    home_service: { title: '', subtitle: '' },
    home_process: { title: '', sub: '', steps: [] },
    home_section_switch: {},
    footer_links: [],
    friend_links: [],
    cs_quick_tags: [],
    cs_auto_reply: ''
  },
  sectionOn: { banner: true, stats: true, packages: true, process: true, banks: true, cases: true, articles: true },
  banners: [],
  services: [],
  banks: [],
  cases: [],
  articles: []
}

const push = await j('/api/admin/workflow/preview', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ token: TOKEN, exp, lang: 'zh', data: snap })
})
ck('POST /admin/workflow/preview 200', push.status === 200 && push.body?.code === 200, `status=${push.status}`)

/* 篡改过期时间必须被拒 */
const pushBad = await j('/api/admin/workflow/preview', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ token: BAD_TOKEN, exp, lang: 'zh', data: snap })
})
ck('篡改 exp 的 token 被拒 400', pushBad.status === 400, `status=${pushBad.status}`)

/* -------------------------------------------------- 2. token 有效性查询 */
const okQ = await j(`/api/public/draft-preview?token=${TOKEN}`)
ck('draft-preview valid=true', okQ.body?.code === 200 && okQ.body?.data?.valid === true, JSON.stringify(okQ.body?.data))
const badQ = await j(`/api/public/draft-preview?token=${BAD_TOKEN}`)
ck('draft-preview 无效 token valid=false', badQ.status === 200 && badQ.body?.data?.valid === false)

/* ------------------------------------------- 3. 首页 HTML 是否渲染草稿横幅 */
const liveHtml = await j('/zh')
ck(
  '正常访问 /zh 无草稿横幅',
  liveHtml.status === 200 && !liveHtml.text.includes('尚未发布') && !/<html[^>]*draft-preview/.test(liveHtml.text),
  `status=${liveHtml.status} htmlClass=${/<html[^>]*draft-preview/.test(liveHtml.text)}`
)

const draftHtml = await j(`/zh?preview=${TOKEN}`)
ck('?preview= 渲染横幅文案', draftHtml.status === 200 && draftHtml.text.includes('尚未发布'), `status=${draftHtml.status}`)
ck('正常访问保留 <html lang="zh-CN">', /<html\s+lang="zh-CN"/.test(liveHtml.text) && !/<html[^>]*class="/.test(liveHtml.text))
ck('<html> 挂上 draft-preview', draftHtml.text.includes('draft-preview'))
ck('横幅含「尚未发布」', draftHtml.text.includes('尚未发布'))

const goneHtml = await j(`/zh?preview=v1.${(Date.now() + 1000).toString(36)}.nope`)
ck('失效 token 显示失效文案', goneHtml.status === 200 && goneHtml.text.includes('预览链接已失效'))

/* ----------------------------------------- 4. 带 preview 的各公开接口读草稿 */
const cfg = await j(`/api/public/config?lang=zh&preview=${TOKEN}`)
ck('config 读到草稿 home_rec.title', cfg.body?.data?.home_rec?.title === '今日推荐-草稿', cfg.body?.data?.home_rec?.title)

const cfgNo = await j('/api/public/config?lang=zh')
ck('config 无 token 仍是原值', cfgNo.body?.data?.home_rec?.title !== '今日推荐-草稿', cfgNo.body?.data?.home_rec?.title)

const bank = await j(`/api/public/bank?lang=zh&preview=${TOKEN}`)
ck('bank 带 token 200（空数组走草稿）', bank.status === 200 && bank.body?.code === 200, `rows=${JSON.stringify(bank.body?.data).slice(0, 30)}`)
const bankNo = await j('/api/public/bank?lang=zh')
ck('bank 无 token 仍返回站点数据', Array.isArray(bankNo.body?.data) && bankNo.body.data.length > 0, `rows=${bankNo.body?.data?.length}`)

const art = await j(`/api/public/article?lang=zh&featured=1&pageSize=3&preview=${TOKEN}`)
ck('article featured 读空草稿仍 200', art.status === 200 && art.body?.code === 200, `rows=${art.body?.data?.rows?.length}`)
const artNo = await j('/api/public/article?lang=zh&featured=1&pageSize=3')
ck('article 无 token 仍有 3 篇', artNo.body?.data?.rows?.length === 3, `rows=${artNo.body?.data?.rows?.length}`)

/* 语言对不上就不套用（草稿是 zh，问 en） */
const artEn = await j(`/api/public/article?lang=en&featured=1&pageSize=3&preview=${TOKEN}`)
ck('语言不一致时不套用草稿', artEn.body?.data?.rows?.length === 3, `rows=${artEn.body?.data?.rows?.length}`)

/* ------------------------------------------------------------------ 5. 回归 */
const svc = await j('/api/public/service?lang=zh&is_home_show=1')
ck('service 正常', svc.status === 200 && Array.isArray(svc.body?.data))
const one = await j('/api/public/article/hk-registry-2026-electronic-search?lang=zh')
ck('article 详情正常', one.status === 200 && !!one.body?.data?.title)
const home = await j('/')
ck('根路径跳 /zh', home.status === 302 || home.status === 200, `status=${home.status} loc=${home.body ? '' : 'html'}`)
const adm = await j('/admin/login')
ck('/admin/login 200', adm.status === 200)

/* ------------------------------------------------------- 6. 后台工作流外壳 */
const cookie = { Cookie: 'yh_admin_token=yh-admin-2026' }
const cms = await j('/admin/cms', { headers: cookie })
ck('/admin/cms 200 且是工作台不是登录页', cms.status === 200 && cms.text.includes('全能管控工作台'), `status=${cms.status}`)
ck(
  '顶栏三按钮 版本记录/操作日志/重置数据',
  cms.text.includes('版本记录') && cms.text.includes('操作日志') && cms.text.includes('重置数据')
)
const modIds = cms.text.match(/ id="mod-/g) || []
ck('8 张模块卡 SSR 出来', modIds.length >= 8, `found=${modIds.length}`)
ck('模块状态徽章已上屏（已发布）', cms.text.includes('已发布'))
ck('发布动作条已上屏（已发布态只有「下线」）', cms.text.includes('下线'))

/* --------------------------------------------- 7. 后台不再出现「演示」字样 */
ck('登录页无「演示」字样', !adm.text.includes('演示'))
ck('工作台无「演示」字样', !cms.text.includes('演示'))
ck('工作台无 flask 图标占位（演示模式徽章）', !cms.text.includes('fa-flask'))
const crm = await j('/admin/crm', { headers: cookie })
ck('CRM 200', crm.status === 200, `status=${crm.status}`)
ck('CRM 无「演示」字样', !crm.text.includes('演示'))
ck('CRM 侧边栏/页签计数仍是 128 口径', crm.text.includes('128'), `has128=${crm.text.includes('128')}`)
const bi = await j('/admin', { headers: cookie })
ck('BI 大屏无「演示」字样', bi.status === 200 && !bi.text.includes('演示'), `status=${bi.status}`)

console.log(lines.join('\n'))
console.log(`\n== PASS ${pass} / FAIL ${fail} ==`)
process.exit(fail ? 1 : 0)
