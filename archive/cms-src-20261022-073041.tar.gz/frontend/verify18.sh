#!/bin/bash
# round18 验收：服务器内冒烟 + 公网页面 + 日志/MD5
B=http://39.105.80.9
CK="Cookie: yh_admin_token=yh-admin-2026"
cd /home/lx/cms-frontend || exit 1

echo "== 1. server smoke16 =="
BASE=http://127.0.0.1:3000 node smoke16.mjs > /tmp/s18.log 2>&1
echo "SMOKE_EXIT=$?"
grep FAIL /tmp/s18.log
tail -2 /tmp/s18.log

echo "== 2. server check17 =="
BASE=http://127.0.0.1:3000 node check17.mjs > /tmp/c18.log 2>&1
echo "CHECK_EXIT=$?"
grep FAIL /tmp/c18.log
tail -2 /tmp/c18.log

echo "== 3. public pages =="
for p in /zh /en /admin/login; do
  echo -n "$p="; curl -s -o /dev/null -w "%{http_code}\n" $B$p
done
for p in /admin /admin/crm /admin/cms /admin/review /admin/audit; do
  echo -n "$p="; curl -s -o /dev/null -w "%{http_code}\n" -H "$CK" $B$p
done

echo "== 4. no demo wording (rendered html) =="
for p in /zh /admin/login /admin/cms /admin/review /admin/audit; do
  if [ "$p" = "/admin/login" ]; then
    n=$(curl -s $B$p | grep -o 演示 | wc -l)
  else
    n=$(curl -s -H "$CK" $B$p | grep -o 演示 | wc -l)
  fi
  echo "$p 演示=$n"
done

echo "== 5. new pages content =="
rv=$(curl -s -H "$CK" $B/admin/review)
echo -n "review 内容审核="; echo "$rv" | grep -o 内容审核 | wc -l
echo -n "review 对比预览="; echo "$rv" | grep -o 对比预览 | wc -l
echo -n "review 共8模块="; echo "$rv" | grep -o "共 8 个模块" | wc -l
echo -n "review 只显示有改动的字段="; echo "$rv" | grep -o 只显示有改动的字段 | wc -l
au=$(curl -s -H "$CK" $B/admin/audit)
echo -n "audit 改前="; echo "$au" | grep -o 改前 | wc -l
echo -n "audit 重置数据="; echo "$au" | grep -o 重置数据 | wc -l
bi=$(curl -s -H "$CK" $B/admin)
echo -n "sidebar 内容审核="; echo "$bi" | grep -o 内容审核 | wc -l
echo -n "sidebar 操作日志="; echo "$bi" | grep -o 操作日志 | wc -l
cr=$(curl -s -H "$CK" $B/admin/crm)
echo -n "crm 深圳跨境电商="; echo "$cr" | grep -o 深圳跨境电商 | wc -l
echo -n "crm 113归档="; echo "$cr" | grep -o "113 条历史线索已归档" | wc -l

echo "== 6. auth guard (anon) =="
echo -n "review_anon="; curl -s -o /dev/null -w "%{http_code}\n" $B/admin/review
echo -n "audit_anon="; curl -s -o /dev/null -w "%{http_code}\n" $B/admin/audit

echo "== 7. logs / pm2 =="
echo -n "error_log_bytes="; stat -c %s /root/.pm2/logs/cms-frontend-error.log
pm2 jlist | python3 -c "import sys,json;d=json.load(sys.stdin);print([(p['name'],p['pm2_env'].get('restart_time')) for p in d])"

echo "== 8. md5 =="
md5sum /home/lx/cms-frontend/app/composables/useContentFlow.ts \
       /home/lx/cms-frontend/app/layouts/admin.vue \
       /home/lx/cms-frontend/app/pages/admin/review.vue \
       /home/lx/cms-frontend/app/pages/admin/audit.vue \
       /home/lx/cms-frontend/server/utils/mock/adminLeads.ts
